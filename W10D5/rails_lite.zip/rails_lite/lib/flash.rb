require 'json'

class Flash
  def initialize(req)
    old_flash = req.cookies["_rails_lite_flash"]
    if old_flash.nil?
      @flash = {}
      @ready_to_clear = false
    else
      @flash = old_flash 
      @ready_to_clear = true
    end
  end

  def now
    @ready_to_clear = true
  end

  def [](key)
    @flash[key]
  end

  def []=(key, val)
    @flash[key] = val
  end
    
end