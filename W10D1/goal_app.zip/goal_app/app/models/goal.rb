class Goal < ApplicationRecord


end