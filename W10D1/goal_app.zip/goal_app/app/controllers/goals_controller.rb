class GoalsController < ApplicationController


end