import React from 'react';
import Clock from './frontend/clock'
const Root = () => {
  return <div> <Clock /> </div>
};


export default Root;